const express = require("express");
const { CreateOrder  } = require("../controllers/payment");

const router = express.Router()
 

router.post("/CreateOrder", CreateOrder)
// router.post("/VerifiyPayment",VarifyPayment)
// router.get("/OrderDetail",GetOrderDetails)


module.exports = router;