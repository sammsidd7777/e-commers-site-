import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";

import ProductDetail from "./pages/ProductDetail";
import LoginPage from "./pages/LoginPage";
import SingupPage from "./pages/SingupPage";
import ShopPage from "./pages/ShopPage";
import Homepage from "./pages/Homepage";
import Cart from "./component/Cart";
import UserDetailpage from "./component/UserDetailpage";
import Addproduct from "./component/AdminPages/Addproduct";
import Wishpage from "./pages/Wishpage";
import AdminPlane from "./component/AdminPages/AdminPlane";
import CheckProduct from "./component/AdminPages/CheckProduct";
import Checkuser from "./component/AdminPages/CheckUser";
import Makeadmin from "./component/AdminPages/Makeadmin";
import Removeadmin from "./component/AdminPages/Removeadmin";
import Protect from "./pages/Protect";




const App = () => {
  const router = createBrowserRouter(
    [
      { path: "/", element: <Homepage /> },
    
      { path: "/shop", element: <ShopPage /> },
      { path: "/signup", element: <SingupPage /> },
      { path: "/login", element: <LoginPage /> },
      { path: "/productDetail/:id", element: <ProductDetail /> },
      { path: '/userdetail', element: <UserDetailpage /> },
      { path: '/cart', element: <Cart /> },
      { path: '/WishPage', element: <Wishpage /> },
 
      {path:"/admin", element: <Protect />, children:[
        { path: "add/product", element: <Addproduct /> },
        { path: 'panel', element: <AdminPlane /> },
        { path: 'admin-product', element: <CheckProduct /> },
        { path: 'checkuser', element: <Checkuser /> },
        { path: 'makeadmin', element: <Makeadmin /> },
        { path: 'removeadmin', element: <Removeadmin /> },
      ]}
  

    ],
  );

  return <RouterProvider router={router} />;
};

export default App;
