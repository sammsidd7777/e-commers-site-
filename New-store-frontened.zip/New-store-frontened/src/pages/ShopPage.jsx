import React, { useEffect, useState } from 'react'
import Header from '../component/Header'
import Footer from '../component/Footer'
import { Link } from 'react-router-dom'

const ShopPage = () => {

  const [product, setproduct] = useState([])
  const [isUserLoggedIn, setIsUserLoggedIn] = useState(false)
  const [userI, setUserId] = useState("")

  const fetchProducts = async () => {
    try {
      const response = await fetch("http://localhost:5200/products/all",)
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      console.log(data.message.fontdata

      )
      setproduct(data.message.fontdata.product);
      console.log(data.message.product);
    } catch (error) {
      console.log("Error fetching products:", error);
    }
  }

  useEffect(() => {
    fetchProducts()
  }, [])


  const sam = async () => {
    try {

      let response = await fetch("http://localhost:5200/user/current", { credentials: "include" });
      if (!response.ok) {
        // setIsUserLoggedIn(false)
        // console.log(response.json())
        throw new Error("Please login your id ");

      }
      else {
        const data = await response.json()
        setUserId(data.message._id)
      }
    } catch (error) {
      alert("ooh your id not login")
    }
  }

  async function handleAddToCart(productId){
    try {
      let response = await fetch("http://localhost:5200/cart/add/"+productId, {credentials: "include"})
      if(!response.ok) throw new Error("Something went wrong!")
      response = await response.json()
      console.log(response)
    } catch (error) {
      console.log(error.message)
    }
  }



 

  return (
    <div className='product-detail-page'>
      <Header />

      <div className="section-box" >
        <div className="product-search">   <input type="search" placeholder='search' /> <button><i className="fa-solid fa-magnifying-glass"></i></button></div>


        <div className="box-deal" style={{ marginTop: '10vw' }}>





          {product.map((item) => (

            <div key={item._id} className="card-section">
              <Link to={"/productDetail/" + item._id}>
                <img
                  src={"http://localhost:5200/images/" + item.productImg[0]}
                  alt=""
                />
              </Link>
              <h2>{item.productName}</h2>
             
              <h4>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
              </h4>
              <div className="price-icon">
                             
                               <i className="fa-regular fa-heart" onClick={() => handleAddToWish(item._id)}></i>
                             
                               <p>${item.productPrice} </p>
                               <i class="fa-solid fa-cart-arrow-down" onClick={() => handleAddToCart(item._id)}></i>
             
                             </div>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  )
}

export default ShopPage
