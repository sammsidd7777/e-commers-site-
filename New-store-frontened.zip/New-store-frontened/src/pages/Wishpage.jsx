import   react from "react";

const Wishpage=()=>{



return(

    <h1>wish page</h1>






)




}
export default Wishpage;