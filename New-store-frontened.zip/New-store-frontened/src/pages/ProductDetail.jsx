import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import Header from "../component/Header";
import Footer from "../component/Footer";
import { handleAddToCart } from "./helperCart";
const ProductDetail = () => {

  const [detail, setDetail] = useState(null)

  const [product,setProduct]=useState([])



  const params = useParams();

  const fetchData = async () => {
    const id = params.id;
    try {

      const response = await fetch(`http://localhost:5200/products/detail/${id}`)

      if (!response.ok) { throw new Error(`HTTP error! status: ${response.status}`)}
      const data = await response.json();
 
      setDetail(data.message.datas.product_detail);
      setProduct(data.message.datas.product)
     
    } catch (error) {
      res.status(400).json({status:"400",message: error.message})
    }
  }
  useEffect(() => {
    fetchData();
  }, []);



 

  return (
    <div className="product-detail-page">
      <Header />

       <div className="product-brand"> <h1>{detail?.productBrand}</h1></div>
      <div className="product-detail-container">
        <div className="product-image">
          <div className="product-image-option">
            <img src={"http://localhost:5200/images/"+detail?.productImg[0]} alt="" />
            <img src={"http://localhost:5200/images/"+detail?.productImg[1]} alt="" />
             <img src={"http://localhost:5200/images/"+detail?.productImg[2]} alt="" />

          </div>
          <div className="product-main-img">
         <img
                  src={"http://localhost:5200/images/"+detail?.productImg[0]}
                  alt=""
                />
                
                </div>

        </div>

        <div className="product-detail-info">
          <h2>{detail?.productName}</h2>
          <p>Price: {detail?.productPrice}</p>
          <p className="rating">Rating:4.8 <i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i><i className="fa-solid fa-star"></i> </p>
          


          <div>
            <p>Product Description: {detail?.productDescription}</p>
          </div>
          <button className="button-Addcart" onClick={() => handleAddToCart(detail?._id) }>{Add}</button>


        </div>

      </div>

  <div className="section-box" style={{marginTop:"4vw"}}>
        <h1 style={{color:"white"}}>Similar product </h1>
        <div className="box-deal">
          {product.map((item) => (
         
            <div key={item._id} className="card-section">
              <Link to={"/productDetail/" + item._id}>
                <img
                  src={"http://localhost:5200/images/"+item.productImg[0]}
                  alt=""
                />
              </Link>
              <h2>{item.productName}</h2>
             
              <h4>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
              </h4>
           <div className="price-icon" >
                          
                            <i className="fa-regular fa-heart" onClick={() => handleAddToWish(item._id)} style={{color:"white"}}></i>
                          
                            <p style={{color:"white"}}>${item.productPrice} </p>
                            <i class="fa-solid fa-cart-arrow-down" onClick={() => handleAddToCart(item._id)} style={{color:"white"}}></i>
          
                          </div>
            </div>
          ))}
        </div>
      </div>
      
      <Footer />

    </div>
  )
};

export default ProductDetail;



