import React from 'react'
import SingUp from '../component/SingUp'

const SingupPage = () => {
  return (
    <div>
        <SingUp />
    </div>
  )
}

export default SingupPage