import React, { useEffect } from 'react'
import Login from '../component/Login'
import { Navigate } from 'react-router-dom'
import { useState } from 'react'
const LoginPage = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  async function isUserLoggedIn(){
      let response = await fetch("http://localhost:5200/user/current", {credentials: "include"})
      if(response.ok) setIsLoggedIn(true)
      
   

      
  }




  useEffect(()=>{
    isUserLoggedIn()
  }, [])

  return (
    <div>
        {isLoggedIn ? <Navigate to={"/userdetail"} />: <Login />}
    </div>
  )
}

export default LoginPage