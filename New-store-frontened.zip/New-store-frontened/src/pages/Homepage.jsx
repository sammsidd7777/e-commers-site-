import { useEffect, useState } from "react";
import Header from "../component/Header";
import { Link } from "react-router-dom";
import Footer from "../component/Footer";
import Desktopbackgraund from "../component/Desktopbackgraund";
import { handleAddToCart, handleAddToWish } from "./helperCart";

const Homepage = () => {

  const [bestSellers, setBestSellers] = useState([]);
  const [bigDiscount, setBigDiscount] = useState([]);
  const [newArrivals, setNewArrivals] = useState([]);


  const fatch = async () => {
    try {
      const response = await fetch("http://localhost:5200/products/all");
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setBestSellers(data.message.fontdata.bestSellers);

      setBigDiscount(data.message.fontdata.bigDiscount);
      setNewArrivals(data.message.fontdata.newArrivals);
    } catch (error) {
      throw new Error("response not come form backend");

    }
  };


 
  // Add to wish list 





  useEffect(() => {
    fatch();
  }, []);


  return (
    <div>
      <Header />

      <Desktopbackgraund />
      {/* best deals  */}
      <div className="section-box">
        <h1> Big deals </h1>
        <div className="box-deal">
          {bestSellers.map((item) => (
            <div key={item._id} className="card-section">
              <Link to={"/productDetail/" + item._id}>

                <img
                  src={"http://localhost:5200/images/" + item.productImg[0]}
                  alt=""
                />
              </Link>

                <h2>{item.productName}</h2>
              
                <h4>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                  <i className="fa-solid fa-star"></i>
                </h4>
                <div className="price-icon">
                
                  <i className="fa-regular fa-heart" onClick={() => handleAddToWish(item._id)}></i>
                
                  <p>${item.productPrice} </p>
                  <i class="fa-solid fa-cart-arrow-down" onClick={() => handleAddToCart(item._id)}></i>

                </div>
            </div>
          ))}
        </div>
      </div>

      {/* big discount */}
      <div className="section-box">
        <h1> Big discount </h1>
        <div className="box-deal">
          {bigDiscount.map((item) => (
            <div key={item._id} className="card-section">
              <Link to={"/productDetail/" + item._id}>
                <img
                  src={"http://localhost:5200/images/" + item.productImg[0]}
                  alt=""
                />
              </Link>
              <h2>{item.productName}</h2>
             
              <h4>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
              </h4>
              <div className="price-icon">
                
                <i className="fa-regular fa-heart" onClick={() => handleAddToWish(item._id)}></i>
              
                <p>${item.productPrice} </p>
                <i class="fa-solid fa-cart-arrow-down" onClick={() => handleAddToCart(item._id)}></i>

              </div>
            </div>
          ))}
        </div>
      </div>

      {/* new arrivles  */}
      <div className="section-box">
        <h1> newArrivals </h1>
        <div className="box-deal">
          {newArrivals.map((item) => (
            <div key={item._id} className="card-section">
              <Link to={"/productDetail/" + item._id}>
                <img
                  src={"http://localhost:5200/images/" + item.productImg[0]}
                  alt=""
                />


              </Link>
              <h2>{item.productName}</h2>
             
              <h4>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
              </h4>
              <div className="price-icon">
                
                  <i className="fa-regular fa-heart" onClick={() => handleAddToWish(item._id)}></i>
                
                  <p>${item.productPrice} </p>
                  <i class="fa-solid fa-cart-arrow-down" onClick={() => handleAddToCart(item._id)}></i>

                </div>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Homepage;
