import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
        <div className='footer-section'>
            <h1>Samm-Store</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Auctor libero id et, in gravida. Sit diam duis mauris nulla cursus. Erat et lectus vel ut sollicitudin elit at amet.</p>
        </div>
        
        <div className='footer-section'>
            <h1>About Us</h1>
            <p>Careers</p>
            <p>Our Stores</p>
            <p>Our Cares</p>
            <p>Terms & Conditions</p>
            <p>Privacy Policy</p>
        </div>

        <div className='footer-section'>
            <h1>Customer Care</h1>
            <p>Help Center</p>
            <p>How to Buy</p>
            <p>Track Your Order</p>
            <p>Corporate & Bulk Purchasing</p>
            <p>Returns & Refunds</p>
        </div>


        <div className='footer-section'>
            <h1>Contact Us</h1>
            <p> G-58, kalka jii post</p>
            <p>new delhi-110076</p>
            <p>Email: uilib.help@gmail.com</p>
            <p>Phone: +91 9958 234 365</p>
        </div>




    </div>
  )
}

export default Footer