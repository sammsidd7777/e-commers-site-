import React from 'react'
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
import Header from './Header'
import Homepage from '../pages/Homepage'
const Login = () => {
  const navigate = useNavigate()
  async function loginhandler(e) {
    e.preventDefault()
    try {



      const email = e.target.email.value
      const password = e.target.password.value

      const user = { email, password }



      let response = await fetch("http://localhost:5200/user/login", {
        method: "POST",
        headers: {
          "content-type": "application/json"
        },
        body: JSON.stringify(user),
        credentials: "include"
      })

      if (!response.ok) {
        response = await response.json()
        throw new Error(response.message)
      }

      response = await response.json();
      console.log(response);
      
      // const userRole = response.user.role
      // console.log("user ka role", userRole)
      // if(userRole ==="admin"){
      //   localStorage.setItem("user_role", "admin")
      // }

      <Homepage send={user}/>
      console.log(response)
      navigate("/")

    } catch (error) {
      console.log(error.message)
    }
  }

  return (
    <div className='login-page'>
      <div className='login-image'>

        <img src='https://narawear.com/assets/LoginImage-lh_t_JZT.jpg' alt=' ' />



      </div>
      <div className='login-deatils'>

        <h2>Welcome to</h2>
        <h1>Samm Store</h1>
        <div className='p'>Today is a new day. It's your day. You shape it. You style it. Be the best version of yourself</div>


        <form className='input' onSubmit={loginhandler}>
          <label>Email Id</label>
          <input type='email' name='email' placeholder='email' />

          <label>Password</label>
          <input type='password' name='password' placeholder='password' />
          <p>Forgot password ?</p>
          <h5>By Signing in , I agree to Terms and Conditions and Privacy Policy</h5>
          <button>login</button>
        </form>

        <div>

        </div>

        <p>Dont have an account?    <Link to={"/signup"}> Singup</Link></p>






      </div>



    </div >
  )
}

export default Login