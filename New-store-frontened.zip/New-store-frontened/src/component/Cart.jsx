import React, { useEffect, useState } from "react";
import Header from "./Header";
import Footer from "./Footer"
import { Link } from "react-router-dom";
import axios from "axios";

const Cart = () => {

    const [product, setProduct] = useState([])

    const [totalproduct, setTotalProduct] = useState()
    const [totalPice, setTotalPice] = useState()







    const cartItem = async () => {

        try {
            const response = await fetch("http://localhost:5200/cart/all", { credentials: "include" });

            if (!response.ok) {
                const errorData = await response.json();
                console.log("Error fetching cart data:", errorData.message || "Unknown error");
            } else {
                console.log("Successfully fetched cart data.");
                const data = await response.json();


                setProduct(data.message.Cartdata);
                setTotalProduct(data.message.totalprodcut)
                setTotalPice(data.message.totalPrice)

                console.log(data.message)


            }

        } catch (error) {
            // Catch any errors during the fetch or processing
            console.log("Error:", error.message || error);
        }
    };

    const handalDeleteCartItem = async (item) => {

        let x = item.productId
        try {
            let response = await fetch("http://localhost:5200/cart//Deletecartitem/" + x, { credentials: "include" })
            if (!response) {
                console.log("respon dikt")
            }

            const data = await response.json()

            setTimeout(() => {
                cartItem()
            }, 2000);
            console.log(data)



        } catch (error) {
            console.log(error.message)

        }
    }


    // const loadScripts = (src:String)=>{
    //     return new Promise((resolve)=>{
    //         const script =document.createElement("script");
    //         script.src=src;
    //         script.onload=()=>{
    //             resolve(true);
    //         }
    //         script.onerror=()=>{
    //             resolve(false)
    //         }
    //         document.body.appendChild(script);
    //     })
    // }

    const handlebuyKnow = async (item) => {

        const Id = item;
        console.log(Id)

        

          const res = await axios.post("http://localhost:5200/payment/CreateOrder", { Id }, {
                withCredentials: true,  // Include credentials (cookies)
                headers: {
                    'Content-Type': 'application/json',  // Ensure the content type is JSON
                }
            }).then((response) => {
                console.log("Order created successfully:", response);
                const sam =  response.data
                console.log(sam,"data")







            }).catch((error) => {
                console.error("Error while creating order:", error.response ? error.response.data : error.message);
            });


            

           

            


    }







    useEffect(() => {
        cartItem()
    }, [])

    return (

        <div className="Card-page">
            <Header />

            <div>
                <h2 style={{ margin: "6vw 0vw 1vw 2vw", fontSize: "2vw", letterSpacing: "0.2vw" }}>Your Shopping Cart</h2>
                {product.length === 0 ? (
                    <p>Your cart is empty!</p>
                ) : (
                    <div className="cart-section">
                        <div className="card-display">

                            {product.map((item) => (
                                <div key={item.productId} className="cart-card">



                                    <img src={"http://localhost:5200/images/" + item.productImg[0]} alt="" />
                                    <div className="cart-product-info">
                                        <h3>{item.productTitle}</h3>
                                        <p>Price: ${item.productPrice}</p>
                                        <p>Quantity: {item.quantity} </p>
                                    </div>
                                    <div className="card-cart-icon" >
                                        <p>  <i className="fa-solid fa-trash" onClick={() => handalDeleteCartItem(item)}></i></p>
                                        <p>  <i className="fa-solid fa-plus" onClick={() => handalDeleteCartItem(item)}></i>
                                            <i className="fa-solid fa-minus"></i></p>

                                        <button onClick={() => handlebuyKnow(item.productId)}>buy know</button>


                                    </div>
                                </div>
                            ))}</div>




                        <div className="summary">

                            <div className="summary-heading">
                                <h1>Price details</h1></div>

                            <div className="summary-detail">
                                <h3>product Quanitity:  </h3> <h2> {totalproduct} </h2>
                                <h3>Discount:    </h3> <h2>0</h2>
                                <h3>Delivery Charges:  </h3> <h2>0</h2>
                            </div>
                            <div className="billing-amount">
                                <h3>Total bill amount :   </h3> <h2>{totalPice} </h2>
                                <button >BUY KNOW</button>
                            </div>






                        </div>
                    </div>
                )}
            </div>


            <Footer />
        </div>








    )



}

export default Cart;