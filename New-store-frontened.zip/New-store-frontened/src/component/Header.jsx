import React from 'react'
import { Link } from 'react-router-dom'

const Header = () => {
  async function isUserLoggedIn() {
    let response = await fetch("http://localhost:5200/user/current")
    if (!response.ok) return false
    else return true
  }



  return (
    <>
      <div className='header'>
        <div className='logo'>Sandy store</div>
        <div className='header-option'>
          <Link to={"/"}><h1>Home</h1></Link>

          <Link to={"/shop"}>     <h1>Shop</h1></Link>
          <Link to={"/cart"}> <h1>cart</h1> </Link>
          <Link to={"/About"}><h1> About</h1></Link>

          <Link to={"/login"}>   <h1><i className="fa-solid fa-user"></i></h1></Link>

          <Link to={"/cart"}>
            <h1>
              <i className="fa-solid fa-cart-shopping" ></i>  </h1></Link>
        </div>
      </div>

      <div className='header-before'>

      </div>
    </>
  )
}

export default Header