import React, { useEffect } from "react";
import Myprofileside from "./Myprofileside";



const Wishlist =()=>{

    const fetchData=async()=>{

    }

    useEffect(()=>{
        fetchData()
    },[])

    return(
<>
<Myprofileside />

<div>





</div>


</>
        
    )

}

export default Wishlist