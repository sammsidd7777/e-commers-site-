import React, { useEffect, useState } from "react";
import AdminPlane from "./AdminPlane";
import { Link } from "react-router-dom";

const CheckProduct=()=>{
    const [product,setProduct]=useState([])

    const fatchData = async () => {
        try {
          const response = await fetch("http://localhost:5200/products/all");
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
          const data =await response.json()
       


          setProduct(data.message.fontdata.product)
        //   console.log(setProduct)


         
        } catch (error) {
          throw new Error("response not come form backend");
    
        }
      };



      const handleDeleteProduct=async(item)=>{
        console.log(item)
          try {
            const response = await fetch("http://localhost:5200/products/delete/" +item , {credentials :"include"})
            if(!response.ok){
                throw new Error("product not delete");
                
            }

            
          } catch (error) {
            console.log(error.message)
          }
      }





    useEffect(()=>{
        fatchData()
    },[])


    return(

    <div style={{display:"flex",width:"100%"}}>
        <div className="admin-panal-div">
    <AdminPlane /> </div>
  <div>
    {
      <div className="box-deal" style={{width:"70vw"}}>
      {product.map((item) => (
        <div key={item._id} className="card-section" style={{}}>
          <Link to={"/productDetail/" + item._id}>

            <img
              src={"http://localhost:5200/images/" + item.productImg[0]}
              alt=""
            />
          </Link>

            <h2>{item.productName}</h2>
          
          
            <div className="price-icon">
            
              <i className="fa-regular fa-heart"></i>
            
              <p>${item.productPrice} </p>
              <i className="fa-regular fa-trash-can" onClick={() => handleDeleteProduct(item._id)}></i>

            </div>
        </div>
      ))}
    </div>
    }




  </div>
</div>)

}

export default CheckProduct