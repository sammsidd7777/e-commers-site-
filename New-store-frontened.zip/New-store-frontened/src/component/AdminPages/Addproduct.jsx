import React from "react";
import AdminPlane from "./AdminPlane";
import { useState } from "react";
const Addproduct = () => {
    const [files, setFiles ] = useState(null)

    async function submitHandal(e) {
        e.preventDefault()

        try {


            // const productName = e.target.productName.value;
            // const productBrand = e.target.productbrand.value;
            // const productPrice = e.target.productprice.value;
            // const productCategory = e.target.productCategory.value;
            // const productType = e.target.productType.value;
            // const productDescription = e.target.productDescription.value;
            // const productImg = e.target.productImg.value;

            const form = new FormData()
            form.append("productName",e.target.productName.value )
            form.append("productBrand",e.target.productbrand.value )
            form.append("productPrice",e.target.productprice.value ) 
            form.append("productCategory",e.target.productCategory.value )
            form.append("productType",e.target.productType.value )
            form.append("productDescription",e.target.productDescription.value )
           
            for(let file of  files){
                form.append("productImg", file)
            }
            

            const productData = { productName, productBrand, productPrice, productCategory, productType, productDescription, productImg };

            console.log(productData);


            let response = await fetch("http://localhost:5200/products/add", {
                method: "POST",
                body: form,
                credentials: "include"
            });

            if (!response.ok) {
                response = await response.json()
                throw new Error(response.message)
            }

            const data = await response.json();

            console.log(data)

        } catch (error) {
            console.log(error.message)
        }
    }


    const fileUploadHandler= (e)=>{
        setFiles(e.target.files)
        
    }


    return (

        <div style={{ display: "flex" }}>
            <div className="admin-panal-div">
                <AdminPlane /> </div>
            <div className="Addproduct-form">

                <h1>Addproduct form</h1>

                <form onSubmit={submitHandal} enctype="multipart/form-data">


                    <div>
                        <label htmlFor="">Product Name</label>
                        <input type="text" name="productName" required placeholder="ProductName" />
                    </div>
                    <div>
                        <label htmlFor="">productBrand</label>
                        <input type="text" name="productbrand" required placeholder="productBrand" />
                    </div>

                    <div>
                        <label htmlFor="">productPrice</label>
                        <input type="text" name="productprice" required placeholder="productPrice" />
                    </div>
                    <div>
                        <label htmlFor="">productCategory</label>
                        <input type="text" name="productCategory" required placeholder="productCategory" />
                    </div>
                    <div>
                        <label htmlFor="">productType</label>
                        <input type="text" name="productType" required placeholder="productType" />
                    </div>
                    <div>
                        <label htmlFor="">productDescription</label>
                        <input type="text" name="productDescription" required placeholder="productDescription" />
                    </div>
                    <div>
                        <label htmlFor="">productImg</label>
                        <input onChange={fileUploadHandler} type="file" multiple name="productImg" required placeholder="select-img" />
                    </div>

                    <button type="submit">submit</button>

                </form>

            </div>
        </div>





    )

}

export default Addproduct