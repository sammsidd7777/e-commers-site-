import React from "react";
import Header from "../Header";
import { Link } from "react-router-dom";


const AdminPlane=()=>{

    return(

<div className="admin-section">
 

    <div className="admin-dasktop" style={{position:"fixed"}}>
        <div><h1>product section</h1>
      <Link to={"/admin/add/product"}>  <h2>Add Product</h2></Link>
         <Link to={"/admin/admin-product"}>  <h2> Check and Delete Product</h2></Link>
        <Link to={""}>   <h2>Update Product</h2></Link>
        </div>
        <div>
             <h1>User detail</h1>
          <Link to={"/admin/checkuser"}> <h2>Check user</h2></Link>
          <Link to={""}> <h2>Remove user</h2></Link>
          <Link to={"/admin/makeadmin"}> <h2>Appoint admin</h2></Link>
          <Link to={"/admin/removeadmin"}> <h2>Remove admin</h2></Link>
        </div>

        <button>LogOut</button>
        <button>Delete</button>

      




    </div>





</div>






    )





}

export default AdminPlane;