import React from "react";

const Desktopbackgraund = () => {
  return (
    <>
  
    <div className="desk-top-slid">


        <div className="slider">
        <div className="slider-detail">
          <h1>50% on your first shopping</h1>
          <p style={{color:"white"}}>here you can find best product accouding your </p>

          <button>Shop now</button>
        </div>


        <div className="four-method">
        <div className="method">
          <i className="fa-solid fa-truck-fast"></i>
          <h3>Free shipping</h3>
          <p>Free shipping on all orders over $99</p>
        </div>

        <div className="method">
          <i className="fa-brands fa-cc-amazon-pay"></i>
          <h3>Secure payment</h3>
          <p>Free shipping on all orders over $99</p>
        </div>

        <div className="method">
          <i className="fa-brands fa-cc-amazon-pay"></i>
          <h3>Safe payment</h3>
          <p>safe</p>
        </div>

        <div className="method">
          <i className="fa-solid fa-retweet"></i>
          <h3> return warrenty</h3>
          <p>return your product in a week</p>
        </div>
      </div>

          
        </div>

   



    </div>
    </>
  );
};

export default Desktopbackgraund;
