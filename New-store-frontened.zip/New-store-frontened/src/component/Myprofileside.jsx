import React from "react";
import { Link, useNavigate } from "react-router-dom";

const Myprofileside = () => {
  const navigate=useNavigate()



  const logOutUseAccount = async () => {

    try {
      localStorage.removeItem("user_role")
      const response = await fetch("http://localhost:5200/user/logout", { credentials: "include" })
      if (!response.ok) {
        throw new Error(error);

      }
      else {
        navigate("/login")
      }

    } catch (error) {
      console.log(error)
    }



  }

  const DeleteUserAccount=async()=>{

    try {

      let response = await fetch("http://localhost:5200/user/delete" ,{credentials:"include"} )
      if(!response.ok) throw new Error(error);

      const data=response.json;
      console.log(data)
      
    } catch (error) {
      console.log(error.message)
    }
  }



  return (
    <div className="profile-sidebar">

      <div className="greeting">
        <h1> <i className="fa-solid fa-user"></i> Hello</h1>
      </div>

      <div className="orders">
        <Link to={"/cart"} >  <h1>  <i className="fa-solid fa-box"></i>My Orders <i className="fa-solid fa-truck-fast"></i></h1></Link>

        <div className="account-settings">
          <h1><i className="fa-solid fa-user"></i> Account Setting</h1>
          <Link to={"/userdetail"}> <p style={{fontSize:"1.2vw"}}>Profile information</p></Link>
          <Link>   <p style={{fontSize:"1.2vw"}}>Manage Address</p></Link>
        </div>

        <h1>My Wishlist</h1>

        <button onClick={logOutUseAccount}>LogOut</button>
        <button  onClick={DeleteUserAccount}>Delete Account</button>


       <Link to={"/admin/panel"}> <button >Admin </button></Link>
      </div>



    </div>
  );
};

export default Myprofileside;
